BEFORE START...

Open a Terminal and type:

sudo apt-get update
sudo apt-get install libssl-dev
sudo apt-get install display

Once done...

1. Right click to mount.sh file
2. Select Open With Other Application...
3. Pick gedit and click Select button
4. When the file is open focus on the line: 
	sudo chown -R <userid>: system
5. Change <userid> for your user ID
6. Save and close the file

EXAMPLE:

My user ID is: veronica (all with lower letters)
So in the end for me that line looks like the following:

	sudo chown -R veronica: system

That change needs to be made in order for you to edit to your like the system folder once mounted.

NOTICE: When you start removing bloat apps and/or files a .TRASH folder will be created. DO NOT WORRY about, simply remove that .TRASH folder once you are done editing the system folder and then you are ready to use:

R - Root firmware
P - Pack firmware

... In that order
