#!/bin/bash
# Unpack final firmware
tput clear

if [ -d ./rkExtract ]; then
		echo "There is already a firmware extracted, do you want me to remove it? (Y/N)"
		read DELANS
		case $DELANS in
			Y|y) rm -rf ./rkExtract; sudo rm -rf pre-update.img; sudo rm -rf new-update.img;;
			N|n) exit 0;;
			*) echo "Wrong answer, returning to main menu..."; exit 0;;
		esac
	fi

if [ -d ./system ]; then
		if mount | grep system.img; then
			sudo umount system
			sleep 6
		fi
		rmdir ./system
	fi


echo -e "Please enter the filename of the \nimage you wish to extract:"
read IMGFILE

tput clear
echo "Unpacking Firmware, Please Wait...."
if [ -e "${IMGFILE}" ]; then
		mkdir ./rkExtract
		./rk-tools/img_unpack "${IMGFILE}" temp.img
		./rk-tools/afptool -unpack temp.img ./rkExtract
		sudo rm -rf temp.img
		tput clear
		echo "Extraction Compete! Now mounting system for modifications"	
		mkdir ./system
		e2fsck -f ./rkExtract/Image/system.img
		resize2fs ./rkExtract/Image/system.img 800M
		sudo mount -t ext4 -o loop,rw, ./rkExtract/Image/system.img ./system
		tput clear

		echo "Done unpacking. Make modifications and then run repack."	

else
		exit 0
fi
