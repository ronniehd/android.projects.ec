#!/bin/bash
# Root firmware
tput clear

if [ -f ./rkExtract/Image/system.img ]; then
	if mount | grep system.img; then
		echo "Already mounted"
	else
		sudo mount -t ext4 -o loop,rw, ./rkExtract/Image/system.img ./system
		echo "Image mounted to ./system"
	fi
fi

# if [ -f ./system/app/Superuser.apk ]; then

# 	
rm -rf ./system/app/Superuser.apk
rm -rf ./system/bin/su
rm -rf ./system/xbin/su
rm -rf ./syste#m/bin/busybox
cp ./rooting/Superuser.apk ./system/app/Superuser.apk 
cp ./rooting/su ./system/bin/su
cp ./rooting/busybox ./system/bin/busubox
chown root:root ./system/app/Superuser.apk 
chown root:root ./system/bin/su
chown root:root ./system/bin/busybox
chmod 4755 ./system/bin/su
chmod 755 ./system/bin/busybox
chmod 644 ./system/app/Superuser.apk
ln -s /system/bin/su ./system/xbin/su

echo "Firmware rooted"
