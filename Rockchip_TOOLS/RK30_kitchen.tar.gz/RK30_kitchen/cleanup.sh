#!/bin/bash
# Unpack final firmware
tput clear

if [ -d ./system ]; then
	mount | grep system.img;
		sudo umount system
		sleep 6
	fi
if [ -d ./system ]; then
	rmdir ./system
fi


if [ -d ./rkExtract ]; then
		rm -rf ./rkExtract
fi

if [ -f Loader.bin ]; then
		rm -rf Loader.bin
fi

if [ -f new-update.img ]; then
		rm -rf new-update.img
fi



echo "Cleaned!"
