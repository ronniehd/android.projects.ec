 #!/bin/bash
tput clear
echo "Repacking Firmware, Please Wait...."

LOADER=`find -maxdepth 2 -name "*Loader*.bin"`
if mount | grep system.img; then
	umount ./system
fi

e2fsck -f ./rkExtract/Image/system.img
resize2fs -M ./rkExtract/Image/system.img
./rk-tools/afptool -pack ./rkExtract pre-update.img
./rk-tools/img_maker -rk30 "${LOADER}" 1 0 23 pre-update.img new-update.img
sudo rm -rf pre-update.img
tput clear







echo "Completed Repack"

exit 0
