#!/bin/bash
# Unpack final firmware
tput clear

if [ -f ./rkExtract/Image/system.img ]; then
	if mount | grep system.img; then
		echo "Already mounted"
	else
		sudo mount -t ext4 -o loop,rw, ./rkExtract/Image/system.img ./system
		echo "Image mounted to ./system"
	fi
fi
