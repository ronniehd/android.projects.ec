

showmenu()
{
	clear
	echo "RockChip Kitchen V1.0 www.androidgadget.co.uk"
	echo ""
	echo "------------MAIN MENU------------"
	echo ""
	echo "Options:"
	echo "E - Extract firmware"
	echo "P - Pack firmware"
	echo "M - Manually mount unpacked image"
	echo "R - Root firmware"
	echo "C - Clean files"
	echo ""
	echo ""
	echo "X - eXit RK30 kitchen"
	echo ""
	echo ""
	
	case $ERROR in
		1) echo "Invalid selection, please try again:";;
		*) echo "Please enter your choice:";;
	esac
}

menu()
{
	clear
	while true
	do
		showmenu
		read answer
		case $answer in
			
			E|e) sh extract.sh;;
			P|p) sh repack.sh;;
			C|c) sh cleanup.sh;;
			M|m) sh mount.sh;;
			R|r) sh root.sh;;
			X|x) clear; exit 0;;
			*) ERROR=1; showmenu;;
		esac
		ERROR=0
	done
}


menu
