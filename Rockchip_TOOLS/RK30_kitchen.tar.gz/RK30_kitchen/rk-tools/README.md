rk-tools
========

RockChip tools modified to work with both RK29 and RK30 boards.